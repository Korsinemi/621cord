export * as new_random_post from "./new_random_post.js";
export * as delete_message from "./delete_message.js";
export * as verify from "./verify.js";
export * as terms_of_service from "./terms_of_service.js";
export * as privacy_policy from "./privacy_policy.js";
export * as tags from "./tags.js";
