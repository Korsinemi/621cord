export * as ping from "./ping.js";
export * as random from "./random.js";
export * as prefs from "./prefs.js";
export * as verify from "./verify.js";
export * as terms from "./terms.js";
export * as privacy from "./privacy.js";
export * as help from "./help.js";
